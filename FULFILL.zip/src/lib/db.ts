import Dexie, { type Table } from 'dexie';

export interface InventoryItem {
  id?: number;
  sku: string;
  product: string;
  stock: number;
  location: string;
  category?: string;
  velocity?: 'high' | 'medium' | 'low';
  weight?: number;
  reorderPoint?: number;
  reorderQty?: number;
  updatedAt: string;
}

export interface Order {
  id?: number;
  orderId: string;
  status: 'Pending' | 'Shipped' | 'Returned' | 'Cancelled' | 'QCHold' | 'CrossDock';
  requiredSkus: string;
  priority: 'normal' | 'high' | 'urgent';
  createdAt: string;
  updatedAt: string;
  assignedTo?: string;
  waveId?: string;
}

export interface ReturnRecord {
  id?: number;
  orderId: string;
  sku: string;
  reason: string;
  restocked: boolean;
  quantity: number;
  processedAt: string;
}

export interface InboundRecord {
  id?: number;
  sku: string;
  qty: number;
  bin: string;
  description: string;
  lotNumber?: string;
  serialNumbers?: string;
  expiryDate?: string;
  receivedAt: string;
  crossDockOrderId?: string;
  qcStatus: 'pending' | 'passed' | 'failed';
}

export interface AuditLog {
  id?: number;
  action: string;
  details: string;
  operator: string;
  timestamp: string;
}

export interface User {
  id?: number;
  username: string;
  password: string;
  role: 'admin' | 'operator' | 'supervisor';
  displayName: string;
  createdAt: string;
}

export interface InventoryMovement {
  id?: number;
  sku: string;
  type: 'inbound' | 'outbound' | 'return' | 'adjustment' | 'transfer' | 'cycle_count' | 'qc_adjustment';
  quantity: number;
  fromLocation?: string;
  toLocation?: string;
  orderId?: string;
  operator: string;
  lotNumber?: string;
  note?: string;
  timestamp: string;
}

export interface CycleCount {
  id?: number;
  sku: string;
  location: string;
  expectedQty: number;
  actualQty: number;
  variance: number;
  status: 'pending' | 'completed' | 'rejected';
  operator: string;
  countedAt: string;
  note?: string;
}

export interface ZoneCapacity {
  id?: number;
  zone: string;
  maxCapacity: number;
  currentUtilization: number;
  category?: string;
  velocityTarget?: 'high' | 'medium' | 'low';
}

export interface WorkerTask {
  id?: number;
  type: 'pick' | 'pack' | 'receive' | 'putaway' | 'cycle_count' | 'replenish';
  orderId?: string;
  sku?: string;
  fromLocation?: string;
  toLocation?: string;
  quantity: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  assignedTo: string;
  priority: 'normal' | 'high' | 'urgent';
  createdAt: string;
  completedAt?: string;
  note?: string;
}

export interface ReplenishmentTask {
  id?: number;
  sku: string;
  fromLocation: string;
  toLocation: string;
  quantity: number;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'normal' | 'high';
  createdAt: string;
  completedAt?: string;
}

export interface QCHold {
  id?: number;
  sku: string;
  lotNumber?: string;
  quantity: number;
  reason: string;
  status: 'hold' | 'released' | 'rejected';
  operator: string;
  createdAt: string;
  releasedAt?: string;
}

export interface WaveBatch {
  id?: number;
  waveId: string;
  name: string;
  status: 'open' | 'picking' | 'completed' | 'cancelled';
  orderIds: string;
  zoneProfile: string;
  createdAt: string;
  completedAt?: string;
}

export interface Template {
  id?: number;
  raw: string;
  standard: string;
  createdAt: string;
}

export interface Alias {
  id?: number;
  source: string;
  target: string;
  createdAt: string;
}

export interface Preference {
  id?: number;
  key: string;
  value: string;
  createdAt: string;
}

export interface SimDbEntry {
  id?: number;
  tacPrefix: string;
  expectedOffset: number;
  modelSeries: string;
  type: string;
}

class VortexDB extends Dexie {
  inventory!: Table<InventoryItem>;
  orders!: Table<Order>;
  returns!: Table<ReturnRecord>;
  inbound!: Table<InboundRecord>;
  auditLogs!: Table<AuditLog>;
  users!: Table<User>;
  inventoryMovements!: Table<InventoryMovement>;
  cycleCounts!: Table<CycleCount>;
  zoneCapacities!: Table<ZoneCapacity>;
  workerTasks!: Table<WorkerTask>;
  replenishmentTasks!: Table<ReplenishmentTask>;
  qcHolds!: Table<QCHold>;
  waveBatches!: Table<WaveBatch>;
  templates!: Table<Template>;
  aliases!: Table<Alias>;
  preferences!: Table<Preference>;
  simDb!: Table<SimDbEntry>;

  constructor() {
    super('VortexWMS');
    this.version(3).stores({
      inventory: '++id, sku, location, category, velocity',
      orders: '++id, orderId, status, priority, waveId, assignedTo',
      returns: '++id, orderId, sku',
      inbound: '++id, sku, receivedAt, crossDockOrderId, qcStatus',
      auditLogs: '++id, timestamp',
      users: '++id, username',
      inventoryMovements: '++id, sku, type, timestamp, orderId',
      cycleCounts: '++id, sku, location, status',
      zoneCapacities: '++id, zone',
      workerTasks: '++id, type, status, assignedTo, priority',
      replenishmentTasks: '++id, sku, status',
      qcHolds: '++id, sku, status',
      waveBatches: '++id, waveId, status',
      templates: '++id, raw',
      aliases: '++id, source',
      preferences: '++id, key',
      simDb: '++id, tacPrefix',
    });
  }
}

export const db = new VortexDB();

// Audit log helper
export async function logAction(action: string, details: string, operator: string) {
  await db.auditLogs.add({
    action,
    details,
    operator,
    timestamp: new Date().toISOString(),
  });
}

// Inventory movement logger
export async function logInventoryMovement(
  sku: string,
  type: InventoryMovement['type'],
  quantity: number,
  operator: string,
  opts?: { fromLocation?: string; toLocation?: string; orderId?: string; lotNumber?: string; note?: string }
) {
  await db.inventoryMovements.add({
    sku,
    type,
    quantity,
    operator,
    fromLocation: opts?.fromLocation,
    toLocation: opts?.toLocation,
    orderId: opts?.orderId,
    lotNumber: opts?.lotNumber,
    note: opts?.note,
    timestamp: new Date().toISOString(),
  });
}

// Export all data as JSON
export async function exportAllData() {
  const inventory = await db.inventory.toArray();
  const orders = await db.orders.toArray();
  const returns = await db.returns.toArray();
  const inbound = await db.inbound.toArray();
  const auditLogs = await db.auditLogs.toArray();
  const inventoryMovements = await db.inventoryMovements.toArray();
  const cycleCounts = await db.cycleCounts.toArray();
  const zoneCapacities = await db.zoneCapacities.toArray();
  const workerTasks = await db.workerTasks.toArray();
  const replenishmentTasks = await db.replenishmentTasks.toArray();
  const qcHolds = await db.qcHolds.toArray();
  const waveBatches = await db.waveBatches.toArray();
  const templates = await db.templates.toArray();
  const aliases = await db.aliases.toArray();
  const preferences = await db.preferences.toArray();
  const simDb = await db.simDb.toArray();
  return {
    inventory, orders, returns, inbound, auditLogs,
    inventoryMovements, cycleCounts, zoneCapacities,
    workerTasks, replenishmentTasks, qcHolds, waveBatches,
    templates, aliases, preferences, simDb,
    exportDate: new Date().toISOString(),
  };
}

// Seed data function
export async function seedDatabase() {
  const inventoryCount = await db.inventory.count();
  const ordersCount = await db.orders.count();
  const usersCount = await db.users.count();
  const zoneCount = await db.zoneCapacities.count();
  const simCount = await db.simDb.count();
  const templateCount = await db.templates.count();

  if (inventoryCount === 0) {
    await db.inventory.bulkAdd([
      { sku: 'APP-IP15-256-BLK', product: 'APPLE IPHONE 15 256GB BLACK', stock: 45, location: 'A1-01', category: 'Electronics', velocity: 'high', weight: 0.2, reorderPoint: 10, reorderQty: 20, updatedAt: new Date().toISOString() },
      { sku: 'APP-IP15P-256-ORG', product: 'APPLE IPHONE 15 PRO COSMIC ORANGE 256GB', stock: 8, location: 'A1-02', category: 'Electronics', velocity: 'high', weight: 0.2, reorderPoint: 5, reorderQty: 15, updatedAt: new Date().toISOString() },
      { sku: 'SAM-S24-512-GRY', product: 'SAMSUNG GALAXY S24 TITAN GRAY 512GB', stock: 12, location: 'B2-15', category: 'Electronics', velocity: 'medium', weight: 0.2, reorderPoint: 8, reorderQty: 12, updatedAt: new Date().toISOString() },
      { sku: 'APP-IP15P-512-BLU', product: 'APPLE IPHONE 15 PRO DEEP BLUE 512GB', stock: 23, location: 'A1-03', category: 'Electronics', velocity: 'high', weight: 0.2, reorderPoint: 10, reorderQty: 20, updatedAt: new Date().toISOString() },
      { sku: 'SAM-ZFL-256-PRP', product: 'SAMSUNG Z FLIP SANDY PURPLE 256GB', stock: 6, location: 'B2-16', category: 'Electronics', velocity: 'low', weight: 0.2, reorderPoint: 5, reorderQty: 10, updatedAt: new Date().toISOString() },
      { sku: 'PIX-8-128-BLK', product: 'GOOGLE PIXEL 8 128GB BLACK', stock: 34, location: 'C3-01', category: 'Electronics', velocity: 'medium', weight: 0.2, reorderPoint: 10, reorderQty: 15, updatedAt: new Date().toISOString() },
      { sku: 'APP-IP14-128-RED', product: 'APPLE IPHONE 14 128GB RED', stock: 3, location: 'A1-04', category: 'Electronics', velocity: 'low', weight: 0.2, reorderPoint: 5, reorderQty: 10, updatedAt: new Date().toISOString() },
      { sku: 'SAM-A54-256-WHT', product: 'SAMSUNG A54 256GB WHITE', stock: 56, location: 'B2-17', category: 'Electronics', velocity: 'medium', weight: 0.2, reorderPoint: 15, reorderQty: 25, updatedAt: new Date().toISOString() },
      { sku: 'SAC-USB-C-2M', product: 'USB-C CABLE 2M', stock: 120, location: 'D1-01', category: 'Accessories', velocity: 'high', weight: 0.05, reorderPoint: 30, reorderQty: 50, updatedAt: new Date().toISOString() },
      { sku: 'CASE-IP15-CLR', product: 'IPHONE 15 CLEAR CASE', stock: 85, location: 'D1-02', category: 'Accessories', velocity: 'high', weight: 0.05, reorderPoint: 20, reorderQty: 40, updatedAt: new Date().toISOString() },
      { sku: 'CHRG-WL-15W', product: 'WIRELESS CHARGER 15W', stock: 42, location: 'D1-03', category: 'Accessories', velocity: 'medium', weight: 0.15, reorderPoint: 10, reorderQty: 20, updatedAt: new Date().toISOString() },
      { sku: 'BUDS-WH-ANC', product: 'WIRELESS ANC EARBUDS WHITE', stock: 18, location: 'D2-01', category: 'Audio', velocity: 'medium', weight: 0.05, reorderPoint: 8, reorderQty: 15, updatedAt: new Date().toISOString() },
    ]);
  }

  if (ordersCount === 0) {
    await db.orders.bulkAdd([
      { orderId: 'ORD-9981', status: 'Pending', requiredSkus: 'APP-IP15P-256-ORG, SAM-S24-512-GRY', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9982', status: 'Pending', requiredSkus: 'SAM-S24-512-GRY', priority: 'high', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9983', status: 'Shipped', requiredSkus: 'APP-IP15-256-BLK', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9984', status: 'Pending', requiredSkus: 'APP-IP15P-512-BLU, PIX-8-128-BLK', priority: 'urgent', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9985', status: 'Pending', requiredSkus: 'SAM-A54-256-WHT, SAM-A54-256-WHT', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9986', status: 'Shipped', requiredSkus: 'APP-IP14-128-RED', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9987', status: 'Pending', requiredSkus: 'SAM-ZFL-256-PRP', priority: 'high', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9988', status: 'Pending', requiredSkus: 'SAC-USB-C-2M, CASE-IP15-CLR', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { orderId: 'ORD-9989', status: 'Pending', requiredSkus: 'CHRG-WL-15W, BUDS-WH-ANC', priority: 'normal', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    ]);
  }

  if (usersCount === 0) {
    await db.users.bulkAdd([
      { username: 'VINOVJ', password: 'VINOVJ', role: 'admin', displayName: 'Administrator', createdAt: new Date().toISOString() },
      { username: 'operator', password: 'operator', role: 'operator', displayName: 'Staff_01', createdAt: new Date().toISOString() },
      { username: 'supervisor', password: 'supervisor', role: 'supervisor', displayName: 'Supervisor', createdAt: new Date().toISOString() },
    ]);
  }

  if (zoneCount === 0) {
    await db.zoneCapacities.bulkAdd([
      { zone: 'A1', maxCapacity: 500, currentUtilization: 0, category: 'Electronics', velocityTarget: 'high' },
      { zone: 'A2', maxCapacity: 400, currentUtilization: 0, category: 'Electronics', velocityTarget: 'high' },
      { zone: 'B1', maxCapacity: 300, currentUtilization: 0, category: 'Electronics', velocityTarget: 'medium' },
      { zone: 'B2', maxCapacity: 300, currentUtilization: 0, category: 'Electronics', velocityTarget: 'medium' },
      { zone: 'C1', maxCapacity: 200, currentUtilization: 0, category: 'Audio', velocityTarget: 'low' },
      { zone: 'C2', maxCapacity: 200, currentUtilization: 0, category: 'Audio', velocityTarget: 'low' },
      { zone: 'C3', maxCapacity: 200, currentUtilization: 0, category: 'Electronics', velocityTarget: 'medium' },
      { zone: 'D1', maxCapacity: 400, currentUtilization: 0, category: 'Accessories', velocityTarget: 'high' },
      { zone: 'D2', maxCapacity: 300, currentUtilization: 0, category: 'Accessories', velocityTarget: 'medium' },
      { zone: 'E1', maxCapacity: 250, currentUtilization: 0, category: 'Returns', velocityTarget: 'low' },
    ]);
  }

  if (simCount === 0) {
    await db.simDb.bulkAdd([
      { tacPrefix: '35123456', expectedOffset: 8, modelSeries: 'Galaxy S20', type: 'Smartphone' },
      { tacPrefix: '35234567', expectedOffset: 8, modelSeries: 'Galaxy S21', type: 'Smartphone' },
      { tacPrefix: '35345678', expectedOffset: 8, modelSeries: 'Galaxy S22', type: 'Smartphone' },
      { tacPrefix: '35456789', expectedOffset: 8, modelSeries: 'Galaxy S23', type: 'Smartphone' },
      { tacPrefix: '35567890', expectedOffset: 8, modelSeries: 'Galaxy S24', type: 'Smartphone' },
      { tacPrefix: '35678901', expectedOffset: 8, modelSeries: 'Galaxy Z Flip', type: 'Smartphone' },
      { tacPrefix: '35789012', expectedOffset: 8, modelSeries: 'Galaxy Z Fold', type: 'Smartphone' },
      { tacPrefix: '35890123', expectedOffset: 8, modelSeries: 'Galaxy A54', type: 'Smartphone' },
      { tacPrefix: '35901234', expectedOffset: 8, modelSeries: 'iPhone 15', type: 'Smartphone' },
      { tacPrefix: '35012345', expectedOffset: 8, modelSeries: 'iPhone 15 Pro', type: 'Smartphone' },
    ]);
  }

  if (templateCount === 0) {
    await db.templates.bulkAdd([
      { raw: 'IPHONE 15 BLACK 256GB', standard: 'APPLE IPHONE 15 256GB BLACK', createdAt: new Date().toISOString() },
      { raw: 'SAMSUNG GALAXY S24 GRAY 512', standard: 'SAMSUNG GALAXY S24 TITAN GRAY 512GB', createdAt: new Date().toISOString() },
      { raw: 'IPHONE 15 PRO BLUE 512', standard: 'APPLE IPHONE 15 PRO DEEP BLUE 512GB', createdAt: new Date().toISOString() },
      { raw: 'Z FLIP PURPLE 256', standard: 'SAMSUNG Z FLIP SANDY PURPLE 256GB', createdAt: new Date().toISOString() },
      { raw: 'PIXEL 8 BLACK 128', standard: 'GOOGLE PIXEL 8 128GB BLACK', createdAt: new Date().toISOString() },
      { raw: 'USB C CABLE 2 METER', standard: 'USB-C CABLE 2M', createdAt: new Date().toISOString() },
      { raw: 'IPHONE 15 CLEAR CASE', standard: 'IPHONE 15 CLEAR CASE', createdAt: new Date().toISOString() },
      { raw: 'WIRELESS CHARGER 15 WATT', standard: 'WIRELESS CHARGER 15W', createdAt: new Date().toISOString() },
      { raw: 'ANC EARBUDS WHITE', standard: 'WIRELESS ANC EARBUDS WHITE', createdAt: new Date().toISOString() },
    ]);
  }
}
