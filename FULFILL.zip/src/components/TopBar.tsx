import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import SyncStatus from './SyncStatus';
import { User, Shield } from 'lucide-react';

export default function TopBar() {
  const { user, isAdmin } = useAuth();
  const [isOnline, setIsOnline] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    setIsOnline(navigator.onLine);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(timer);
    };
  }, []);

  return (
    <header className="fixed top-0 left-[240px] right-0 h-14 glass-panel border-b border-white/[0.06] flex items-center justify-between px-5 z-40">
      <div className="flex items-center gap-4">
        <SyncStatus isOnline={isOnline} />
      </div>

      <div className="flex items-center gap-5">
        <div className="text-xs text-text-secondary font-mono">
          {currentTime.toLocaleTimeString('en-US', { hour12: false })}
          {' \u2022 '}
          {currentTime.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
        </div>

        <div className="h-5 w-px bg-white/10" />

        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-accent-orange/20 flex items-center justify-center">
            {isAdmin ? (
              <Shield className="w-3.5 h-3.5 text-accent-orange" />
            ) : (
              <User className="w-3.5 h-3.5 text-accent-orange" />
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-text-primary leading-tight">
              {user?.displayName || 'Unknown'}
            </span>
            <span className="text-[10px] text-text-secondary uppercase tracking-wider">
              {isAdmin ? 'Admin' : 'Operator'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
