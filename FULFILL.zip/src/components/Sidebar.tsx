import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/auth';
import {
  LayoutDashboard,
  Package,
  PackageOpen,
  ClipboardList,
  RotateCcw,
  ScanBarcode,
  Scale,
  RefreshCw,
  Settings,
  Users,
  LogOut,
  Hexagon,
  BarChart3,
  ClipboardCheck,
  Zap,
  ShieldCheck,
  FileText,
  Brain,
  Smartphone,
  Shield,
} from 'lucide-react';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: Package, label: 'Inbound Receiving', path: '/inbound' },
  { icon: ClipboardList, label: 'Inventory Hub', path: '/inventory' },
  { icon: PackageOpen, label: 'Pick & Pack', path: '/pick-pack' },
  { icon: RotateCcw, label: 'Returns', path: '/returns' },
  { icon: ScanBarcode, label: 'PDF Sequencer', path: '/pdf-sequencer' },
  { icon: Scale, label: 'Auditor', path: '/auditor' },
  { icon: RefreshCw, label: 'Bulk Converter', path: '/bulk-convert' },
  { icon: FileText, label: 'Templates', path: '/templates' },
  { icon: Brain, label: 'Memory', path: '/memory' },
];

const advancedItems = [
  { icon: ClipboardCheck, label: 'Cycle Count', path: '/cycle-count' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
  { icon: Zap, label: 'Replenishment', path: '/replenishment' },
  { icon: ShieldCheck, label: 'QC Management', path: '/qc' },
];

const adminItems = [
  { icon: Users, label: 'User Management', path: '/users' },
  { icon: Smartphone, label: 'SIM Manager', path: '/sim-manager' },
  { icon: Shield, label: 'Guardian Ops', path: '/guardian' },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAdmin, logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 h-full w-[240px] bg-surface border-r border-white/[0.06] flex flex-col z-50">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/[0.06]">
        <div className="w-9 h-9 bg-accent-orange rounded-lg flex items-center justify-center">
          <Hexagon className="w-5 h-5 text-void" />
        </div>
        <div>
          <h1 className="text-sm font-bold text-text-primary tracking-tight">YESI-FULFILLMENT</h1>
          <p className="text-[10px] text-text-secondary uppercase tracking-widest">Warehouse Ops</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 px-3 overflow-y-auto">
        <div className="text-[10px] text-text-secondary uppercase tracking-widest px-3 mb-2 mt-2">Operations</div>
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150 group ${
                isActive
                  ? 'bg-surface-hover text-text-primary'
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover/50'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-5 bg-accent-orange rounded-r-full"
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                />
              )}
              <item.icon className={`w-4 h-4 ${isActive ? 'text-accent-orange' : ''}`} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}

        <div className="text-[10px] text-text-secondary uppercase tracking-widest px-3 mb-2 mt-4">Advanced</div>
        {advancedItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150 group ${
                isActive
                  ? 'bg-surface-hover text-text-primary'
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover/50'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-5 bg-accent-orange rounded-r-full"
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                />
              )}
              <item.icon className={`w-4 h-4 ${isActive ? 'text-accent-orange' : ''}`} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}

        {isAdmin && (
          <>
            <div className="text-[10px] text-text-secondary uppercase tracking-widest px-3 mb-2 mt-4">Administration</div>
            {adminItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150 group ${
                    isActive
                      ? 'bg-surface-hover text-text-primary'
                      : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover/50'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-5 bg-accent-orange rounded-r-full"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <item.icon className={`w-4 h-4 ${isActive ? 'text-accent-orange' : ''}`} />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </>
        )}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-white/[0.06]">
        <button
          onClick={() => navigate('/settings')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150 mb-1 ${
            location.pathname === '/settings'
              ? 'bg-surface-hover text-text-primary'
              : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover/50'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span className="font-medium">Settings</span>
        </button>

        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-text-secondary hover:text-accent-red hover:bg-accent-red/10 transition-all duration-150"
        >
          <LogOut className="w-4 h-4" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
