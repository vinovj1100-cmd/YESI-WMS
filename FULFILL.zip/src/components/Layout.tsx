import { Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import HolographicBackground from './HolographicBackground';

export default function Layout() {
  const location = useLocation();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-void">
      <HolographicBackground />
      <Sidebar />
      <TopBar />

      <main className="relative flex-1 ml-[240px] mt-14 overflow-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="p-6"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
