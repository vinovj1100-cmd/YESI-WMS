import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { db, logAction } from '@/lib/db';
import { useAuth } from '@/lib/auth';
import {
  RefreshCw, Copy, CheckCircle, Wand2, Database, FileText,
  Languages, Loader2, AlertTriangle, X, Globe
} from 'lucide-react';
import type { Template } from '@/lib/db';

// ─── Constants ────────────────────────────────────────────────────────────────

const TITLE_MAPPINGS: Record<string, string> = {
  'IPHONE': 'APPLE IPHONE',
  ' ORANGE': ' COSMIC ORANGE',
  ' BLUE': ' DEEP BLUE',
  ' GRAY': ' TITAN GRAY',
  ' GREY': ' TITAN GRAY',
  ' PURPLE': ' SANDY PURPLE',
  'SMARTPHONE ': '',
  'MOBILE PHONE ': '',
};

const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'ru', label: 'Russian' },
  { code: 'zh-CN', label: 'Chinese (Simplified)' },
  { code: 'tr', label: 'Turkish' },
  { code: 'ar', label: 'Arabic' },
  { code: 'de', label: 'German' },
  { code: 'fr', label: 'French' },
  { code: 'es', label: 'Spanish' },
  { code: 'it', label: 'Italian' },
  { code: 'ja', label: 'Japanese' },
  { code: 'ko', label: 'Korean' },
  { code: 'pt', label: 'Portuguese' },
  { code: 'pl', label: 'Polish' },
  { code: 'uk', label: 'Ukrainian' },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function standardizeTitle(rawText: string): string {
  let text = rawText.toUpperCase();
  for (const [key, value] of Object.entries(TITLE_MAPPINGS)) {
    if (text.includes(key) && (value === '' || !text.includes(value))) {
      text = text.replace(key, value);
    }
  }
  return text.trim();
}

/**
 * Google Translate unofficial endpoint — no API key needed.
 * Translates a single text string using the public translate.googleapis.com endpoint.
 */
async function googleTranslate(text: string, target: string, source = 'auto'): Promise<string> {
  if (!text.trim()) return text;
  const url =
    `https://translate.googleapis.com/translate_a/single` +
    `?client=gtx&sl=${source}&tl=${target}&dt=t&q=${encodeURIComponent(text)}`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`Google Translate error: ${res.status}`);
  const data = await res.json();
  // Response shape: [ [ ["translated", "original", ...], ... ], ... ]
  const translated: string = data[0]
    .map((chunk: any[]) => chunk[0])
    .join('');
  return translated;
}

// ─── Types ────────────────────────────────────────────────────────────────────

type OutputMode = 'template' | 'standardize' | 'combined';
type LineStatus = 'pending' | 'translating' | 'done' | 'error';

interface LineResult {
  original: string;
  translated?: string;
  standardized: string;
  templateMatch?: string;
  final: string;
  status: LineStatus;
  error?: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function BulkConverter() {
  const { user } = useAuth();
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [copied, setCopied] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [outputMode, setOutputMode] = useState<OutputMode>('standardize');
  const [stats, setStats] = useState({ processed: 0, matched: 0, translated: 0 });

  // Translation state
  const [enableTranslation, setEnableTranslation] = useState(false);
  const [sourceLang, setSourceLang] = useState('auto');
  const [targetLang, setTargetLang] = useState('en');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [lineResults, setLineResults] = useState<LineResult[]>([]);
  const [translateError, setTranslateError] = useState<string | null>(null);
  const abortRef = useRef(false);

  const loadTemplates = useCallback(async () => {
    const items = await db.templates.toArray();
    setTemplates(items);
  }, []);

  useEffect(() => { loadTemplates(); }, [loadTemplates]);

  const suggestTemplate = (text: string): string | null => {
    const upper = text.toUpperCase();
    for (const t of templates) {
      const rawUpper = t.raw.toUpperCase();
      if (upper.includes(rawUpper) || rawUpper.includes(upper)) return t.standard;
      const rawWords = rawUpper.split(/\s+/);
      const textWords = upper.split(/\s+/);
      const common = rawWords.filter(w => textWords.includes(w)).length;
      if (common >= Math.max(2, rawWords.length * 0.5)) return t.standard;
    }
    return null;
  };

  const handleConvert = async () => {
    if (!input.trim()) return;
    abortRef.current = false;
    setIsProcessing(true);
    setTranslateError(null);
    setLineResults([]);
    setProgress(0);

    const rawLines = input.split('\n');
    const nonEmptyLines = rawLines.filter(l => l.trim());
    const results: LineResult[] = rawLines.map(l => ({
      original: l,
      standardized: '',
      final: '',
      status: l.trim() ? 'pending' : 'done',
    }));
    setLineResults([...results]);

    let matchedCount = 0;
    let translatedCount = 0;
    let nonEmptyProcessed = 0;

    for (let i = 0; i < rawLines.length; i++) {
      if (abortRef.current) break;
      const line = rawLines[i];
      if (!line.trim()) {
        results[i] = { ...results[i], final: '', status: 'done' };
        continue;
      }

      results[i] = { ...results[i], status: 'translating' };
      setLineResults([...results]);

      try {
        // Step 1: Translate if enabled
        let workingText = line.trim();
        if (enableTranslation && sourceLang !== targetLang) {
          workingText = await googleTranslate(line.trim(), targetLang, sourceLang);
          results[i].translated = workingText;
          translatedCount++;
        }

        // Step 2: Standardize
        const std = standardizeTitle(workingText);
        results[i].standardized = std;

        // Step 3: Template match
        const templateMatch = suggestTemplate(std);
        results[i].templateMatch = templateMatch || undefined;
        if (templateMatch) matchedCount++;

        // Step 4: Compose final output
        let final = std;
        if (templateMatch) {
          if (outputMode === 'template') final = templateMatch;
          else if (outputMode === 'combined') final = `${templateMatch} [${std}]`;
        }
        results[i].final = final;
        results[i].status = 'done';
      } catch (e: any) {
        results[i].status = 'error';
        results[i].error = e.message;
        results[i].final = line.toUpperCase(); // fallback
        setTranslateError(`Translation failed on line ${i + 1}: ${e.message}`);
      }

      nonEmptyProcessed++;
      setProgress(Math.round((nonEmptyProcessed / nonEmptyLines.length) * 100));
      setLineResults([...results]);
    }

    const finalOutput = results.map(r => r.final).join('\n');
    setOutput(finalOutput);
    setStats({ processed: nonEmptyLines.length, matched: matchedCount, translated: translatedCount });
    setIsProcessing(false);

    await logAction(
      'BULK_CONVERT',
      `Processed ${nonEmptyLines.length} lines, ${matchedCount} templates matched, ${translatedCount} translated`,
      user?.displayName || 'Unknown'
    );
  };

  const handleAbort = () => { abortRef.current = true; };

  const handleCopy = async () => {
    if (!output) return;
    try {
      await navigator.clipboard.writeText(output);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = output;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const inputCount = input.split('\n').filter(Boolean).length;
  const outputCount = output.split('\n').filter(Boolean).length;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-text-primary">Bulk Title Converter</h1>
        <p className="text-sm text-text-secondary mt-1">Standardize, translate, and apply templates to product titles in bulk</p>
      </div>

      {/* ── Translation Panel ── */}
      <div className="mb-4 glass-panel rounded-lg p-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <Globe className="w-4 h-4 text-accent-orange" />
            <span className="text-sm font-semibold text-text-primary">Google Translate</span>
            {/* Toggle */}
            <button
              onClick={() => setEnableTranslation(v => !v)}
              className={`relative w-10 h-5 rounded-full transition-colors ${enableTranslation ? 'bg-accent-orange' : 'bg-white/10'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${enableTranslation ? 'translate-x-5' : ''}`} />
            </button>
            {enableTranslation && (
              <span className="text-[10px] text-accent-orange font-semibold uppercase tracking-wider">Active</span>
            )}
          </div>

          <AnimatePresence>
            {enableTranslation && (
              <motion.div
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                className="flex items-center gap-2 overflow-hidden"
              >
                <div className="flex items-center gap-1">
                  <label className="text-[10px] text-text-secondary">From</label>
                  <select
                    value={sourceLang}
                    onChange={e => setSourceLang(e.target.value)}
                    className="bg-white/[0.05] border border-white/[0.08] text-xs text-text-primary rounded-md px-2 py-1 focus:outline-none focus:border-accent-orange"
                  >
                    <option value="auto">Auto-detect</option>
                    {LANGUAGES.map(l => (
                      <option key={l.code} value={l.code}>{l.label}</option>
                    ))}
                  </select>
                </div>
                <Languages className="w-3.5 h-3.5 text-text-secondary" />
                <div className="flex items-center gap-1">
                  <label className="text-[10px] text-text-secondary">To</label>
                  <select
                    value={targetLang}
                    onChange={e => setTargetLang(e.target.value)}
                    className="bg-white/[0.05] border border-white/[0.08] text-xs text-text-primary rounded-md px-2 py-1 focus:outline-none focus:border-accent-orange"
                  >
                    {LANGUAGES.map(l => (
                      <option key={l.code} value={l.code}>{l.label}</option>
                    ))}
                  </select>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {enableTranslation && (
          <p className="text-[10px] text-text-secondary mt-2">
            Uses the free Google Translate public endpoint — no API key required. Each line is translated individually before standardization.
          </p>
        )}
      </div>

      {/* ── Output Mode ── */}
      <div className="mb-4 flex gap-2 flex-wrap">
        {([
          { key: 'standardize' as OutputMode, label: 'Standardize Only' },
          { key: 'template' as OutputMode, label: 'Template Only' },
          { key: 'combined' as OutputMode, label: 'Combined (Template + Std)' },
        ]).map(m => (
          <button
            key={m.key}
            onClick={() => setOutputMode(m.key)}
            className={`px-3 py-1.5 text-[10px] rounded-md border transition-all uppercase tracking-wider font-semibold ${
              outputMode === m.key
                ? 'bg-accent-orange/20 border-accent-orange/40 text-accent-orange'
                : 'bg-white/[0.02] border-white/[0.06] text-text-secondary hover:bg-white/[0.04]'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* ── Progress Bar ── */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mb-4 glass-panel rounded-lg p-3"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 text-accent-orange animate-spin" />
                <span className="text-xs text-text-primary">
                  {enableTranslation ? 'Translating & Processing...' : 'Processing...'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-accent-orange font-semibold">{progress}%</span>
                <button
                  onClick={handleAbort}
                  className="flex items-center gap-1 text-[10px] text-accent-red border border-accent-red/30 px-2 py-0.5 rounded hover:bg-accent-red/10 transition-colors"
                >
                  <X className="w-3 h-3" /> Cancel
                </button>
              </div>
            </div>
            <div className="w-full h-1.5 bg-white/[0.06] rounded-full overflow-hidden">
              <motion.div
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
                className="h-full rounded-full bg-accent-orange"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Error Banner ── */}
      <AnimatePresence>
        {translateError && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mb-4 p-3 bg-accent-red/10 border border-accent-red/20 rounded-lg flex items-start gap-2"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-accent-red flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-accent-red flex-1">{translateError}</p>
            <button onClick={() => setTranslateError(null)}><X className="w-3 h-3 text-accent-red" /></button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Main Panels ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Input */}
        <div className="glass-panel rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <RefreshCw className="w-4 h-4 text-accent-orange" />
            <h3 className="text-sm font-semibold text-text-primary">Input (Original Titles)</h3>
            <span className="ml-auto text-[10px] text-text-secondary">{inputCount} lines</span>
          </div>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            className="w-full h-72 bg-transparent border border-white/[0.08] rounded-md p-3 text-xs text-text-primary font-mono resize-none focus:outline-none focus:border-accent-orange transition-colors"
            placeholder="Paste original product titles here, one per line..."
          />
        </div>

        {/* Output */}
        <div className="glass-panel rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="w-4 h-4 text-accent-green" />
            <h3 className="text-sm font-semibold text-text-primary">Output</h3>
            <div className="ml-auto flex items-center gap-2">
              {outputCount > 0 && <span className="text-[10px] text-text-secondary">{outputCount} lines</span>}
              {output && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-[10px] bg-white/[0.05] text-text-secondary px-2 py-1 rounded hover:bg-white/[0.08] transition-colors"
                >
                  {copied ? <CheckCircle className="w-3 h-3 text-accent-green" /> : <Copy className="w-3 h-3" />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              )}
            </div>
          </div>
          <textarea
            value={output}
            readOnly
            className="w-full h-72 bg-transparent border border-white/[0.08] rounded-md p-3 text-xs text-text-primary font-mono resize-none focus:outline-none"
            placeholder="Converted titles will appear here..."
          />
        </div>
      </div>

      {/* ── Action ── */}
      <div className="flex items-center justify-center mt-4">
        <motion.button
          onClick={handleConvert}
          whileTap={{ scale: 0.98 }}
          disabled={!input.trim() || isProcessing}
          className="flex items-center gap-2 px-6 py-3 bg-accent-orange text-void font-semibold text-sm rounded-md hover:bg-accent-orange/90 transition-colors disabled:opacity-30"
        >
          {isProcessing
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <Wand2 className="w-4 h-4" />
          }
          {isProcessing ? `Processing... ${progress}%` : (enableTranslation ? 'Translate & Convert' : 'Convert & Standardize')}
        </motion.button>
      </div>

      {stats.processed > 0 && !isProcessing && (
        <div className="mt-3 text-center space-x-4">
          <span className="text-[10px] text-text-secondary">
            Processed <span className="text-text-primary font-semibold">{stats.processed}</span> titles
          </span>
          <span className="text-[10px] text-text-secondary">
            Templates matched: <span className="text-accent-orange font-semibold">{stats.matched}</span>
          </span>
          {enableTranslation && (
            <span className="text-[10px] text-text-secondary">
              Translated: <span className="text-accent-green font-semibold">{stats.translated}</span>
            </span>
          )}
        </div>
      )}

      {/* ── Per-line Results (shown while processing) ── */}
      <AnimatePresence>
        {lineResults.length > 0 && isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-4 glass-panel rounded-lg p-4 max-h-52 overflow-y-auto"
          >
            <h3 className="text-[10px] text-text-secondary uppercase tracking-widest mb-2">Live Processing Log</h3>
            <div className="space-y-0.5">
              {lineResults.filter(r => r.original.trim()).map((r, i) => (
                <div key={i} className="flex items-center gap-2 py-0.5">
                  {r.status === 'translating' && <Loader2 className="w-3 h-3 text-accent-orange animate-spin flex-shrink-0" />}
                  {r.status === 'done' && <CheckCircle className="w-3 h-3 text-accent-green flex-shrink-0" />}
                  {r.status === 'error' && <AlertTriangle className="w-3 h-3 text-accent-red flex-shrink-0" />}
                  {r.status === 'pending' && <div className="w-3 h-3 rounded-full border border-white/20 flex-shrink-0" />}
                  <span className="text-[10px] text-text-secondary truncate">{r.original}</span>
                  {r.translated && r.translated !== r.original && (
                    <>
                      <span className="text-[10px] text-white/30">→</span>
                      <span className="text-[10px] text-accent-orange truncate">{r.translated}</span>
                    </>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Mapping Legend + Templates ── */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass-panel rounded-lg p-4">
          <h3 className="text-[10px] text-text-secondary uppercase tracking-widest mb-3">Keyword Mappings</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {Object.entries(TITLE_MAPPINGS).map(([from, to]) => (
              <div key={from} className="flex items-center gap-2 p-2 bg-white/[0.02] rounded-md">
                <span className="text-[10px] font-mono text-accent-red">{from.trim() || '(remove)'}</span>
                <span className="text-[10px] text-text-secondary">→</span>
                <span className="text-[10px] font-mono text-accent-green">{to.trim() || '(remove)'}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <Database className="w-3.5 h-3.5 text-accent-orange" />
            <h3 className="text-[10px] text-text-secondary uppercase tracking-widest">Template Database</h3>
            <span className="ml-auto text-[10px] text-text-secondary">{templates.length} templates</span>
          </div>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {templates.slice(0, 10).map(t => (
              <div key={t.id} className="flex items-center gap-2 text-[10px] p-1.5 bg-white/[0.02] rounded-md">
                <FileText className="w-3 h-3 text-text-secondary flex-shrink-0" />
                <span className="text-text-secondary truncate">{t.raw}</span>
                <span className="text-text-secondary/50">→</span>
                <span className="text-accent-green truncate">{t.standard}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
