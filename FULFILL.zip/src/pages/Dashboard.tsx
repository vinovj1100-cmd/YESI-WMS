import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { db } from '@/lib/db';
import KineticCounter from '@/components/KineticCounter';
import StatusBadge from '@/components/StatusBadge';
import { useNavigate } from 'react-router-dom';
import {
  Package,
  AlertTriangle,
  Clock,
  CheckCircle,
  RotateCcw,
  Activity,
  TrendingUp,
  Box,
  BarChart3,
  Zap,
  ShieldCheck,
  ClipboardCheck,
  ArrowRight,
} from 'lucide-react';
import type { InventoryItem, Order } from '@/lib/db';

interface Stats {
  totalStock: number;
  lowStock: number;
  pendingOrders: number;
  shippedToday: number;
  totalReturns: number;
  totalSkus: number;
  qcHolds: number;
  pendingCounts: number;
  reorderAlerts: number;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats>({
    totalStock: 0,
    lowStock: 0,
    pendingOrders: 0,
    shippedToday: 0,
    totalReturns: 0,
    totalSkus: 0,
    qcHolds: 0,
    pendingCounts: 0,
    reorderAlerts: 0,
  });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [lowStockItems, setLowStockItems] = useState<InventoryItem[]>([]);
  const [recentMovements, setRecentMovements] = useState<any[]>([]);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const inventory = await db.inventory.toArray();
    const orders = await db.orders.toArray();
    const returns = await db.returns.toArray();
    const qcHolds = await db.qcHolds.toArray();
    const counts = await db.cycleCounts.toArray();

    const totalStock = inventory.reduce((sum, item) => sum + (item.stock || 0), 0);
    const lowStock = inventory.filter(item => (item.stock || 0) < (item.reorderPoint || 10));
    const pending = orders.filter(o => o.status === 'Pending');
    const shipped = orders.filter(o => o.status === 'Shipped');
    const reorderAlerts = inventory.filter(item => item.reorderPoint && (item.stock || 0) <= item.reorderPoint);

    setStats({
      totalStock,
      lowStock: lowStock.length,
      pendingOrders: pending.length,
      shippedToday: shipped.length,
      totalReturns: returns.length,
      totalSkus: inventory.length,
      qcHolds: qcHolds.filter(h => h.status === 'hold').length,
      pendingCounts: counts.filter(c => c.status === 'pending').length,
      reorderAlerts: reorderAlerts.length,
    });

    setRecentOrders(orders.slice(-5).reverse());
    setLowStockItems(lowStock.slice(0, 5));

    const movements = await db.inventoryMovements.reverse().limit(5).toArray();
    setRecentMovements(movements);
  };

  const kpiCards = [
    { label: 'Total Items in Stock', value: stats.totalStock, icon: Box, color: 'text-accent-orange', delay: 0 },
    { label: 'Low Stock Alerts', value: stats.lowStock, icon: AlertTriangle, color: 'text-accent-red', alert: true, delay: 0.05 },
    { label: 'Pending Orders', value: stats.pendingOrders, icon: Clock, color: 'text-accent-yellow', delay: 0.1 },
    { label: 'Shipped Today', value: stats.shippedToday, icon: CheckCircle, color: 'text-accent-green', delay: 0.15 },
  ];

  const quickLinks = [
    { label: 'Analytics', icon: BarChart3, path: '/analytics', color: 'text-accent-orange', desc: 'View warehouse KPIs' },
    { label: 'Replenishment', icon: Zap, path: '/replenishment', color: 'text-accent-yellow', desc: `${stats.reorderAlerts} reorder alerts` },
    { label: 'QC Management', icon: ShieldCheck, path: '/qc', color: 'text-accent-red', desc: `${stats.qcHolds} active holds` },
    { label: 'Cycle Count', icon: ClipboardCheck, path: '/cycle-count', color: 'text-accent-green', desc: `${stats.pendingCounts} pending counts` },
  ];

  return (
    <div>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-text-primary">Operations Center</h1>
        <p className="text-sm text-text-secondary mt-1">Real-time warehouse performance overview</p>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpiCards.map((kpi) => (
          <motion.div
            key={kpi.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: kpi.delay, duration: 0.3 }}
            className="glass-panel rounded-lg p-4"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] text-text-secondary uppercase tracking-widest">{kpi.label}</span>
              <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
            </div>
            <KineticCounter value={kpi.value} size={44} />
          </motion.div>
        ))}
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {quickLinks.map((link, i) => (
          <motion.button
            key={link.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.05, duration: 0.3 }}
            onClick={() => navigate(link.path)}
            className="glass-panel rounded-lg p-4 text-left hover:border-accent-orange/30 transition-all border border-transparent"
          >
            <div className="flex items-center justify-between mb-2">
              <link.icon className={`w-4 h-4 ${link.color}`} />
              <ArrowRight className="w-3 h-3 text-text-secondary" />
            </div>
            <p className="text-xs font-semibold text-text-primary">{link.label}</p>
            <p className="text-[10px] text-text-secondary mt-0.5">{link.desc}</p>
          </motion.button>
        ))}
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.3 }}
          className="glass-panel rounded-lg p-4 text-center"
        >
          <Package className="w-5 h-5 text-accent-orange mx-auto mb-2" />
          <div className="text-2xl font-bold text-text-primary">{stats.totalSkus}</div>
          <div className="text-[10px] text-text-secondary uppercase tracking-widest mt-1">Active SKUs</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.3 }}
          className="glass-panel rounded-lg p-4 text-center"
        >
          <RotateCcw className="w-5 h-5 text-accent-yellow mx-auto mb-2" />
          <div className="text-2xl font-bold text-text-primary">{stats.totalReturns}</div>
          <div className="text-[10px] text-text-secondary uppercase tracking-widest mt-1">Total Returns</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="glass-panel rounded-lg p-4 text-center"
        >
          <TrendingUp className="w-5 h-5 text-accent-green mx-auto mb-2" />
          <div className="text-2xl font-bold text-accent-green">{(stats.shippedToday / (stats.pendingOrders + stats.shippedToday || 1) * 100).toFixed(0)}%</div>
          <div className="text-[10px] text-text-secondary uppercase tracking-widest mt-1">Fulfillment Rate</div>
        </motion.div>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Low Stock Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="glass-panel rounded-lg p-4"
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-accent-red" />
            <h3 className="text-sm font-semibold text-text-primary">Low Stock Alerts</h3>
            {lowStockItems.length > 0 && (
              <span className="ml-auto text-[10px] bg-accent-red/20 text-accent-red px-2 py-0.5 rounded-full">
                {lowStockItems.length} items
              </span>
            )}
          </div>

          {lowStockItems.length === 0 ? (
            <p className="text-xs text-text-secondary py-4 text-center">All stock levels are healthy</p>
          ) : (
            <div className="space-y-2">
              {lowStockItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2.5 bg-accent-red/5 border border-accent-red/10 rounded-md"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-text-primary truncate">{item.product}</p>
                    <p className="text-[10px] text-text-secondary font-mono">{item.sku}</p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    <span className="text-xs font-bold text-accent-red">{item.stock} left</span>
                    <span className="text-[10px] text-text-secondary font-mono">{item.location}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.3 }}
          className="glass-panel rounded-lg p-4"
        >
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-accent-orange" />
            <h3 className="text-sm font-semibold text-text-primary">Recent Orders</h3>
          </div>

          <div className="space-y-2">
            {recentOrders.map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between p-2.5 bg-white/[0.02] border border-white/[0.06] rounded-md"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-medium text-text-primary">{order.orderId}</span>
                    <StatusBadge status={order.status} />
                  </div>
                  <p className="text-[10px] text-text-secondary font-mono mt-1 truncate">{order.requiredSkus}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Movements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.3 }}
        className="glass-panel rounded-lg p-4 mt-4"
      >
        <div className="flex items-center gap-2 mb-4">
          <Activity className="w-4 h-4 text-accent-green" />
          <h3 className="text-sm font-semibold text-text-primary">Recent Inventory Movements</h3>
        </div>
        {recentMovements.length === 0 ? (
          <p className="text-xs text-text-secondary text-center py-4">No movements recorded yet</p>
        ) : (
          <div className="space-y-2">
            {recentMovements.map((m) => (
              <div key={m.id} className="flex items-center justify-between p-2.5 bg-white/[0.02] border border-white/[0.06] rounded-md">
                <div className="flex items-center gap-3">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                    m.type === 'inbound' ? 'bg-accent-green/20 text-accent-green' :
                    m.type === 'outbound' ? 'bg-accent-red/20 text-accent-red' :
                    m.type === 'return' ? 'bg-accent-yellow/20 text-accent-yellow' :
                    'bg-white/10 text-text-secondary'
                  }`}>{m.type}</span>
                  <span className="text-xs font-mono text-text-primary">{m.sku}</span>
                  <span className="text-[10px] text-text-secondary">{m.quantity} units</span>
                </div>
                <span className="text-[10px] text-text-secondary font-mono">{m.operator}</span>
              </div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}
