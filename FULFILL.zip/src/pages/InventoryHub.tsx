import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { db } from '@/lib/db';
import { AlertTriangle, Search, Package, MapPin } from 'lucide-react';
import type { InventoryItem } from '@/lib/db';

const ZONES = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'C3', 'D1', 'D2', 'E1'];

const VELOCITY_COLORS: Record<string, string> = {
  high: 'text-accent-orange',
  medium: 'text-accent-yellow',
  low: 'text-text-secondary',
};

export default function InventoryHub() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editStock, setEditStock] = useState('');
  const [hoveredLocation, setHoveredLocation] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [filterVelocity, setFilterVelocity] = useState<string | null>(null);

  const loadInventory = useCallback(async () => {
    const items = await db.inventory.toArray();
    setInventory(items);
  }, []);

  useEffect(() => {
    loadInventory();
  }, [loadInventory]);

  const categories = [...new Set(inventory.map(i => i.category).filter((c): c is string => !!c))];

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.category?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesCategory = !filterCategory || item.category === filterCategory;
    const matchesVelocity = !filterVelocity || item.velocity === filterVelocity;
    return matchesSearch && matchesCategory && matchesVelocity;
  });

  const handleStockUpdate = async (id: number) => {
    const newStock = parseInt(editStock);
    if (isNaN(newStock) || newStock < 0) return;
    await db.inventory.update(id, { stock: newStock, updatedAt: new Date().toISOString() });
    setEditingId(null);
    loadInventory();
  };

  const getLocationZone = (location: string) => {
    return location.split('-')[0] || location;
  };

  const getItemsInZone = (zone: string) => {
    return inventory.filter(item => getLocationZone(item.location).startsWith(zone));
  };

  const isLowStock = (item: InventoryItem) => {
    const threshold = item.reorderPoint ?? 10;
    return (item.stock || 0) <= threshold;
  };

  const lowStockCount = inventory.filter(isLowStock).length;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-text-primary">Inventory Hub</h1>
        <p className="text-sm text-text-secondary mt-1">Master stock list and zone management</p>
      </div>

      {/* Low Stock Banner */}
      {lowStockCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-3 bg-accent-red/10 border border-accent-red/20 rounded-md flex items-center gap-3"
        >
          <AlertTriangle className="w-4 h-4 text-accent-red flex-shrink-0" />
          <p className="text-xs text-accent-red">
            <strong>ACTION REQUIRED:</strong> {lowStockCount} SKU(s) at or below reorder point
          </p>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Zone Map */}
        <div className="lg:col-span-2 glass-panel rounded-lg p-4">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-accent-orange" />
            <h3 className="text-sm font-semibold text-text-primary">Zone Map</h3>
          </div>

          <div className="grid grid-cols-5 gap-1">
            {ZONES.map(zone => {
              const items = getItemsInZone(zone);
              const totalStock = items.reduce((s, i) => s + (i.stock || 0), 0);
              const hasLow = items.some(i => isLowStock(i));
              const isHovered = hoveredLocation === zone;

              return (
                <motion.div
                  key={zone}
                  className={`aspect-square rounded-md border flex flex-col items-center justify-center cursor-pointer transition-all ${
                    isHovered
                      ? 'bg-accent-orange/20 border-accent-orange/40'
                      : hasLow
                        ? 'bg-accent-red/5 border-accent-red/20'
                        : items.length > 0
                          ? 'bg-white/[0.03] border-white/[0.08]'
                          : 'bg-transparent border-white/[0.04]'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  onMouseEnter={() => setHoveredLocation(zone)}
                  onMouseLeave={() => setHoveredLocation(null)}
                >
                  <span className="text-[10px] text-text-secondary font-mono">{zone}</span>
                  <span className={`text-sm font-bold ${hasLow ? 'text-accent-red' : 'text-text-primary'}`}>
                    {totalStock}
                  </span>
                  <span className="text-[9px] text-text-secondary">{items.length} SKUs</span>
                </motion.div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 mt-4 text-[10px] text-text-secondary">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-sm bg-white/[0.03] border border-white/[0.08]" />
              <span>Occupied</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-sm bg-accent-red/5 border border-accent-red/20" />
              <span>Low Stock</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-sm bg-transparent border border-white/[0.04]" />
              <span>Empty</span>
            </div>
          </div>

          {/* Category Filter */}
          {categories.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/[0.06]">
              <p className="text-[10px] text-text-secondary uppercase tracking-widest mb-2">Filter by Category</p>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setFilterCategory(null)}
                  className={`text-[10px] px-2 py-1 rounded-md transition-all ${!filterCategory ? 'bg-accent-orange/20 text-accent-orange' : 'bg-white/[0.03] text-text-secondary'}`}
                >
                  All
                </button>
                {categories.map((cat: string) => (
                  <button
                    key={cat}
                    onClick={() => setFilterCategory(cat === filterCategory ? null : cat)}
                    className={`text-[10px] px-2 py-1 rounded-md transition-all ${filterCategory === cat ? 'bg-accent-orange/20 text-accent-orange' : 'bg-white/[0.03] text-text-secondary'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Velocity Filter */}
          <div className="mt-3">
            <p className="text-[10px] text-text-secondary uppercase tracking-widest mb-2">Filter by Velocity</p>
            <div className="flex gap-1.5">
              {(['high', 'medium', 'low'] as const).map(v => (
                <button
                  key={v}
                  onClick={() => setFilterVelocity(filterVelocity === v ? null : v)}
                  className={`text-[10px] px-2 py-1 rounded-md transition-all capitalize ${filterVelocity === v ? 'bg-accent-orange/20 text-accent-orange' : 'bg-white/[0.03] text-text-secondary'}`}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Master Stock Table */}
        <div className="lg:col-span-3 glass-panel rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-accent-orange" />
              <h3 className="text-sm font-semibold text-text-primary">Master Stock List</h3>
              <span className="text-[10px] text-text-secondary">{filteredInventory.length} items</span>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-text-secondary absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search SKU, product, location..."
                className="bg-white/[0.03] border border-white/[0.08] rounded-md pl-8 pr-3 py-1.5 text-xs text-text-primary placeholder:text-text-secondary/50 focus:outline-none focus:border-accent-orange transition-colors w-56"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-[10px] text-text-secondary uppercase tracking-widest border-b border-white/[0.06]">
                  <th className="text-left py-2 px-2">SKU</th>
                  <th className="text-left py-2 px-2">Product</th>
                  <th className="text-center py-2 px-2">Stock</th>
                  <th className="text-center py-2 px-2">ROP</th>
                  <th className="text-center py-2 px-2">Location</th>
                  <th className="text-center py-2 px-2">Velocity</th>
                  <th className="text-center py-2 px-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredInventory.map((item) => {
                  const low = isLowStock(item);
                  return (
                    <tr
                      key={item.id}
                      className={`border-b border-white/[0.04] transition-colors ${
                        low ? 'animate-pulse-red' : 'hover:bg-white/[0.02]'
                      }`}
                      onMouseEnter={() => setHoveredLocation(getLocationZone(item.location))}
                      onMouseLeave={() => setHoveredLocation(null)}
                    >
                      <td className="py-2 px-2 text-xs font-mono text-text-primary">{item.sku}</td>
                      <td className="py-2 px-2 text-xs text-text-primary max-w-[140px] truncate">
                        <div>{item.product}</div>
                        {item.category && <div className="text-[9px] text-text-secondary">{item.category}</div>}
                      </td>
                      <td className="py-2 px-2 text-center">
                        {editingId === item.id ? (
                          <input
                            type="number"
                            value={editStock}
                            onChange={(e) => setEditStock(e.target.value)}
                            onBlur={() => handleStockUpdate(item.id!)}
                            onKeyDown={(e) => e.key === 'Enter' && handleStockUpdate(item.id!)}
                            className="w-16 bg-transparent border-b border-accent-orange text-center text-xs text-text-primary font-mono focus:outline-none"
                            autoFocus
                          />
                        ) : (
                          <button
                            onClick={() => { setEditingId(item.id!); setEditStock(String(item.stock || 0)); }}
                            className={`text-xs font-mono font-semibold ${low ? 'text-accent-red' : 'text-text-primary'}`}
                          >
                            {item.stock}
                          </button>
                        )}
                      </td>
                      <td className="py-2 px-2 text-center text-[10px] font-mono text-text-secondary">{item.reorderPoint ?? '-'}</td>
                      <td className="py-2 px-2 text-center text-[10px] font-mono text-text-secondary">{item.location}</td>
                      <td className="py-2 px-2 text-center">
                        <span className={`text-[9px] font-semibold capitalize ${VELOCITY_COLORS[item.velocity || 'low']}`}>
                          {item.velocity || 'low'}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold ${
                          low
                            ? 'bg-accent-red/20 text-accent-red'
                            : 'bg-accent-green/20 text-accent-green'
                        }`}>
                          {low ? 'LOW' : 'OK'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredInventory.length === 0 && (
            <p className="text-xs text-text-secondary text-center py-8">No items found</p>
          )}
        </div>
      </div>
    </div>
  );
}
